//
//  main.c
//  libgeneral
//
//  Created by tihmstar on 03.05.19.
//  Copyright © 2019 tihmstar. All rights reserved.
//

#include <stdio.h>
#include "Event.hpp"
#include "DeliveryEvent.hpp"
#include "lck_container.hpp"
#include "Manager.hpp"

int main(int argc, const char * argv[]) {
    // insert code here...
    printf("Hello, World!\n");
    return 0;
}
